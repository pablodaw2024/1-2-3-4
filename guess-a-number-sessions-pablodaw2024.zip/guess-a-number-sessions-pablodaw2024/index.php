<?php
session_start();
require "vendor/autoload.php";

use eftec\bladeone\BladeOne;

$views = __DIR__ . '/views'; // Usar barras diagonales para la compatibilidad
$cache = __DIR__ . '/cache';

$blade = new BladeOne($views, $cache, BladeOne::MODE_DEBUG);

// Si se está enviando el formulario para establecer límites
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['boundsbutton'])) {
        $lowerbound = (int)$_POST['lowerbound'];
        $upperbound = (int)$_POST['upperbound'];
        $attempts = (int)$_POST['attempts']; // Captura el número de intentos

        // Validar los límites y el número de intentos
        if ($lowerbound < $upperbound && $attempts > 0) {
            $_SESSION['lowerbound'] = $lowerbound;
            $_SESSION['upperbound'] = $upperbound;
            $_SESSION['attempts'] = $attempts; // Guardar los intentos
            
            // Generar un número secreto aleatorio entre los límites
            $_SESSION['secretNumber'] = rand($lowerbound, $upperbound);
            $_SESSION['attemptsLeft'] = $attempts; // Reiniciar los intentos restantes
            $_SESSION['gameStarted'] = true; // Iniciar el juego

            // Mostrar el mensaje de inicio del juego
            $message = "¡El juego ha comenzado! Tienes " . $_SESSION['attemptsLeft'] . " intentos para adivinar el número secreto.";
            echo $blade->run('bounds', ['message' => $message, 'attempts' => $_SESSION['attemptsLeft'], 'isGuessing' => true]);
        } else {
            $boundsError = true;
            echo $blade->run('bounds', ['boundsError' => $boundsError]);
        }
    } elseif (isset($_POST['guessbutton'])) {
        // Si se está procesando un intento
        $guess = (int)$_POST['guess'];
        $secretNumber = $_SESSION['secretNumber'];
        $_SESSION['attemptsLeft']--;

        if ($guess === $secretNumber) {
            $resultMessage = "¡Felicidades! Adivinaste el número: $secretNumber";
            $_SESSION['gameStarted'] = false; // Terminar el juego
            echo $blade->run('bounds', ['message' => $resultMessage]);
        } elseif ($_SESSION['attemptsLeft'] === 0) {
            $resultMessage = "¡Juego terminado! El número era: $secretNumber. No tienes más intentos.";
            $_SESSION['gameStarted'] = false; // Terminar el juego
            echo $blade->run('bounds', ['message' => $resultMessage]);
        } else {
            $hint = $guess < $secretNumber ? "Tu intento es muy bajo." : "Tu intento es muy alto.";
            echo $blade->run('bounds', [
                'message' => $hint,
                'attempts' => $_SESSION['attemptsLeft'],
                'isGuessing' => true
            ]);
        }
    }
} else {
    // Primer acceso a la aplicación
    echo $blade->run('bounds');
}
?>
