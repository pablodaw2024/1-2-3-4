@extends('app')
@section('title', 'Formulario para ingresar límites del juego')
@section('content')
@if (isset($message))
    <p class="info-section">{{ $message }}</p>
@endif

@if (isset($isGuessing) && $isGuessing)
    <!-- Formulario para hacer la adivinanza -->
    <form class="form-font" name="form_guess" action="index.php" method="POST">
        <div class="form-section">
            <label for="guess">Tu adivinanza:</label>
            <input id="guess" type="number" required name="guess" min="{{ $_SESSION['lowerbound'] }}" max="{{ $_SESSION['upperbound'] }}" />
        </div>
        <p>Intentos restantes: {{ $attempts }}</p>
        <div class="submit-section-2">
            <input type="submit" value="Adivinar" name="guessbutton" /> 
        </div>
    </form>
@else
    <!-- Formulario para establecer límites y el número de intentos -->
    <form class="form-font" name="form_bounds" action="index.php" method="POST">
        <div class="form-section">
            <label for="lowerbound">Límite inferior:</label>
            <input autofocus id="lowerbound" type="number" required name="lowerbound" min="0"/> 
        </div>
        <div class="form-section">
            <label for="upperbound">Límite superior:</label>
            <input id="upperbound" type="number" required name="upperbound" min="1"/> 
        </div>
        <div class="form-section">
            <label for="attempts">Número de intentos:</label>
            <input id="attempts" type="number" required name="attempts" min="1" value="5"/> 
        </div>
        @if (!empty($boundsError))
            <p class="info-section">El límite superior debe ser mayor que el límite inferior y el número de intentos debe ser mayor que 0.</p>
        @endif
        <div class="submit-section-2">
            <input type="submit" value="Enviar" name="boundsbutton" /> 
        </div>
    </form>
@endif
@endsection 
