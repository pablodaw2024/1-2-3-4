<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Equipos de la Liga</title>
</head>
<body>
    <h1>Introduce los Equipos</h1>
    <form method="POST" action="">
        <textarea name="team_names" rows="10" cols="30" placeholder="Escribe un equipo por línea" required></textarea>
        <br>
        <input type="submit" value="Crear Partidos">
    </form>
</body>
</html>
