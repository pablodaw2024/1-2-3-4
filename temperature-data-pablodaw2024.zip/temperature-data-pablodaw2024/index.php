<?php
// Incluir Composer y BladeOne
require 'vendor/autoload.php';

use eftec\bladeone\BladeOne;

session_start(); // Iniciar sesión para guardar los datos entre peticiones

// Definir las rutas de las vistas y el caché
$views = __DIR__ . '/views'; 
$cache = __DIR__ . '/cache';

// Crear la instancia de BladeOne
$blade = new BladeOne($views, $cache, BladeOne::MODE_DEBUG);

// Procesar el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar si se envió el formulario de temperaturas
    if (isset($_POST['city_name'])) {
        $city = $_POST['city_name'];
        $temperatures = [];
        
        // Guardar las temperaturas máximas y mínimas para cada mes
        for ($i = 1; $i <= 12; $i++) {
            $temperatures[$i] = [
                'max' => (int)$_POST["max_$i"],
                'min' => (int)$_POST["min_$i"]
            ];
        }
        
        // Guardar los datos en la sesión
        $_SESSION['cities'][$city] = $temperatures;
    }

    // Si se envió el formulario de ver resultados
    if (isset($_POST['show_results'])) {
        $city_data = $_SESSION['cities'];
        $summary = [];

        foreach ($city_data as $city => $months) {
            $max_temp = $min_temp = 0;
            $total_max = $total_min = 0;
            $total_avg = 0;

            foreach ($months as $month) {
                $total_max += $month['max'];
                $total_min += $month['min'];
            }
            
            $max_temp = $total_max / 12; // Promedio máximo
            $min_temp = $total_min / 12; // Promedio mínimo
            $total_avg = ($total_max + $total_min) / 24; // Promedio general

            // Guardar los resultados
            $summary[] = [
                'city' => $city,
                'max_temp' => $max_temp,
                'min_temp' => $min_temp,
                'avg_temp' => $total_avg
            ];
        }

        // Ordenar por: temperatura máxima (desc), mínima (asc) y alfabéticamente
        usort($summary, function($a, $b) {
            if ($a['max_temp'] == $b['max_temp']) {
                if ($a['min_temp'] == $b['min_temp']) {
                    return strcmp($a['city'], $b['city']);
                }
                return $a['min_temp'] <=> $b['min_temp'];
            }
            return $b['max_temp'] <=> $a['max_temp'];
        });
        
        echo $blade->run('result_table', ['summary' => $summary]);
        exit;
    }
}

// Mostrar el formulario para ingresar las temperaturas
echo $blade->run('temperature_form');
