<!-- views/temperature_form.blade.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>Formulario de Temperaturas</title>
    <link rel="stylesheet" href="/assets/css/stylesheet.css">
</head>
<body>
    <div class="container">
        <h1>Formulario para Ingresar Temperaturas</h1>
        <form action="index.php" method="POST">
            <div class="form-group">
                <label for="city_name">Nombre de la Ciudad:</label>
                <input type="text" id="city_name" name="city_name" required>
            </div>

            <!-- Formulario de temperaturas por mes -->
            @for ($i = 1; $i <= 12; $i++)
                <div class="form-group">
                    <label for="max_{{ $i }}">Temperatura Máxima Mes {{ $i }}:</label>
                    <input type="number" id="max_{{ $i }}" name="max_{{ $i }}" required>
                    
                    <label for="min_{{ $i }}">Temperatura Mínima Mes {{ $i }}:</label>
                    <input type="number" id="min_{{ $i }}" name="min_{{ $i }}" required>
                </div>
            @endfor

            <button type="submit">Guardar Temperaturas</button>
        </form>

        <form action="index.php" method="POST">
            <button type="submit" name="show_results">Ver Resultados</button>
        </form>
    </div>
</body>
</html>
