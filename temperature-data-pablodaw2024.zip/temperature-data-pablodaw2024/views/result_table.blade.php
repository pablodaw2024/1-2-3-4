<!-- views/result_table.blade.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>Tabla de Resultados</title>
    <link rel="stylesheet" href="/assets/css/stylesheet.css">
</head>
<body>
    <div class="container">
        <h1>Resultados Consolidados</h1>
        <table border="1">
            <thead>
                <tr>
                    <th>Ciudad</th>
                    <th>Temperatura Máxima Promedio</th>
                    <th>Temperatura Mínima Promedio</th>
                    <th>Temperatura Promedio General</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($summary as $data)
                    <tr>
                        <td>{{ $data['city'] }}</td>
                        <td>{{ number_format($data['max_temp'], 2) }}°C</td>
                        <td>{{ number_format($data['min_temp'], 2) }}°C</td>
                        <td>{{ number_format($data['avg_temp'], 2) }}°C</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>
</html>
